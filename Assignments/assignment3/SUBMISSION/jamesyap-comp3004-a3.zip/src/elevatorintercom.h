#ifndef ELEVATORINTERCOM_H
#define ELEVATORINTERCOM_H

class ElevatorIntercom
{
public:
    ElevatorIntercom();

    void blinkIndicator();
    void establishVoice();
};

#endif // ELEVATORINTERCOM_H
