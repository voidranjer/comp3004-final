#ifndef ELEVATORFLOORSENSOR_H
#define ELEVATORFLOORSENSOR_H

class ElevatorFloorSensor
{
public:
    ElevatorFloorSensor();

    void detectMe();
};

#endif // ELEVATORFLOORSENSOR_H
