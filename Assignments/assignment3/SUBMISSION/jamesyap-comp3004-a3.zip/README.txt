James Yap
101276054
COMP 3004 Assignment 3

Submission: jamesyap-comp3004-a3.zip

Main file: a3.pdf
Source code: src/*
Demo video: https://youtu.be/sIcVdbwe8Yo