#ifndef DEFS_H
#define DEFS_H

// Directions
#define UP 1
#define DOWN -1
#define STOP 0

#endif