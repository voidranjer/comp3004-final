James Yap
101276054
COMP 3004 Assignment 2

Main file: a2.pdf
Headers: headers/*
